package com.Savings;

import java.util.Scanner;

public class Saving 
{
	
	static double amount=30000.00;
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the withdrawal money");
		double a=sc.nextDouble();
		System.out.println("enter the adding money");
		double b=sc.nextDouble();
		
		try
		{
			TotalSavings.withdraw(a);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		TotalSavings t=new TotalSavings();
		t.add(b);
		t.display();

	}

	
}
