package com.Savings;

public class Insufficient extends Exception {
	Insufficient(String message)
	{
		super(message);
	}

}
