package com.Savings;

public class TotalSavings 
{
	static void withdraw(double wdamount) throws Insufficient
	{
		if(Saving.amount<wdamount)
		{
			throw new Insufficient("********Withdrawal is failed********");
		}
		else
		{
			Saving.amount=Saving.amount-wdamount;
		}
	}
	void add(double addamount)
	{
	
			Saving.amount=Saving.amount+addamount;
			
	}
	void display()
	{
			System.out.println("your current balance:"+ Saving.amount);
	}
}
	
	


