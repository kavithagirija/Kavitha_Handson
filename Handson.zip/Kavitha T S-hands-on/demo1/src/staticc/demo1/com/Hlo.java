package staticc.demo1.com;

public class Hlo {
	static int length;
	void rectangle(int breadth)
	{
		System.out.println("area of rectangle:"+(length*breadth));
	}
	 static void square()
	{
		System.out.println("area of square:"+(length*length));
	}
	void circle(int radius)
	{
		System.out.println("area of circle:"+(3.14*radius*radius));
	}
}