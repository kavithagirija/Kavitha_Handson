package staticc.demo1.com;

public class Hie {

	public static void main(String[] args) 
	{
		Hlo h=new Hlo();
		Hlo.length=10;
		h.rectangle(3);
		Hlo.square();
		h.circle(5);
}
}