package tom.com;

public class Movie {

	public static void main(String[] args) {
		Billing b=new Billing();
		b.display();
	}

}
