package tom.com;

import java.util.Scanner;

public class Billing {
	public void display()
	{
	 Scanner ka=new Scanner(System.in);
	
	 System.out.println("Enter the number of pizzas bought:");
	 int pizza=ka.nextInt();
	 
	 System.out.println("Enter the number of puffs bought:");
	 int puff=ka.nextInt();
	 
	 System.out.println("Enter the no of cooldrinks bought:");
	 int cool=ka.nextInt();
		
	 int total;
	 total=pizza+puff+cool;
	 System.out.println("Total price:"+total);
	}
	 

}
