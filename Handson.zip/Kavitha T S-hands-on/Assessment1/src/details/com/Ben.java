package details.com;

public class Ben {

	public static void main(String[] args) {
		Register r=new Register();
		r.display();
	}

}
