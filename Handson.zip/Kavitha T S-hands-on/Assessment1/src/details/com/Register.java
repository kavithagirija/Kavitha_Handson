package details.com;

import java.util.Scanner;

public class Register {
	public void display()
	{
	 Scanner si=new Scanner(System.in);
	
	 System.out.println("Enter your name:");
	 String name=si.next();
	 
	 System.out.println("Enter age:");
	 int age=si.nextInt();
	 
	 System.out.println("Enter gender:");
	 String gender=si.next();
	
	 System.out.println("Hailing from:");
	 String place=si.next();
	 
	 System.out.println("welcome,"+name+"!");
	}
	 

}
