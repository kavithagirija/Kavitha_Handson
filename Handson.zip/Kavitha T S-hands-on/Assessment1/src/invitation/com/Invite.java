package invitation.com;

public class Invite {

	public static void main(String[] args) {
		Welcome w=new Welcome();
		w.display();

	}

}
