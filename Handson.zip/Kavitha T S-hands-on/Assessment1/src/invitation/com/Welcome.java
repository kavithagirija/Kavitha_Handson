package invitation.com;

public class Welcome {
	void display()
	{
		System.out.println("Welcome to object oriented programming");
	}

}
