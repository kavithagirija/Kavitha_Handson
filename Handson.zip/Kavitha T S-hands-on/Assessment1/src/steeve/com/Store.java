package steeve.com;

public class Store {
	String a;
	int b;
	long c;
	String d;
	String f;
	float g;
	
	public Store(String a,int b,long c,String d,String f,float g)
	{
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
		this.f=f;
		this.g=g;
		
	}
    void display()
    {
    System.out.println("Dear "+a+", Thanks for registering in our portal, registration id will be mailed to "+f+"within 2 working days");
    }
}
