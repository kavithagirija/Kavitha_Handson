package steeve.com;

import java.util.Scanner;

public class Registration {

	public static void main(String[] args) {
		Scanner hi=new Scanner(System.in);
		
		System.out.println("Enter your name:");
		String name=hi.next();
		System.out.println("Enter your age:");
		int age=hi.nextInt();
		System.out.println("Enter your Phone no:");
		Long no=hi.nextLong();
		System.out.println("Enter your qualification:");
		String qua=hi.next();
		System.out.println("Enter your email id[please provide your valid email id, after registration your registration id will be mailed]:");
		String email=hi.next();
		System.out.println("Enter your noofexperience[if any]:");
		Float exp=hi.nextFloat();
		
		Store sr=new Store(name,age,no,qua,email,exp);
		sr.display();
	}

}
