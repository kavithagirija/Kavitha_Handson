package employee;

import java.util.Scanner;

public class Getdet {

	public static void main(String[] args) {
		Empdet f=new Empdet(11,"suraj",23,24000,"programmer");
        f.createemp();
		Empdet f1=new Empdet(12,"manju",22,15000,"analyst");
		f1.createemp();
		Empdet f2=new Empdet(13,"indra",26,20000,"programmer");
		f2.createemp();
		Empdet f3=new Empdet(14,"akshara",25,20000,"developer");
		f3.createemp();
		Empdet f4=new Empdet(15,"naitik",29,40000,"manager");
		f4.createemp();
		
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter id:");
		int a=ss.nextInt();
		System.out.println("Employee name:");
		String b=ss.next();
		System.out.println("Enter age:");
		int c=ss.nextInt();
		System.out.println("Enter salary:");
		Long d=ss.nextLong();
		System.out.println("Enter designation");
		String e=ss.next();
		
		Empdet ee=new Empdet(a,b,c,d,e);
		ee.fixsalary();
		ee.raisesalary();
		ee.displaysal();
		
		System.out.println("Enter choice:");
		int n=ss.nextInt();
		
		switch(n)
		{
		case 1:
			Scanner st=new Scanner(System.in);
			System.out.println("Employee name:");
			String bb=st.next();
			System.out.println("Enter age:");
			int cc=st.nextInt();
			System.out.println("Enter salary:");
			Long dd=st.nextLong();
			System.out.println("Enter designation");
			String ef=st.next();
			Empdet gg=new Empdet(bb,cc,dd,ef);
			gg.display();
		break;
		case 2:
			Scanner tt=new Scanner(System.in);
			System.out.println("Employee name:");
			String bbb=tt.next();
			System.out.println("Enter age:");
			int ccc=tt.nextInt();
			System.out.println("Enter salary:");
			Long ddd=tt.nextLong();
			System.out.println("Enter designation");
			String eff=tt.next();
			Empdet ggg=new Empdet(bbb,ccc,ddd,eff);
			ggg.display();
		break;
		case 3:
			Scanner kt=new Scanner(System.in);
			System.out.println("Employee name:");
			String bt=kt.next();
			System.out.println("Enter age:");
			int ct=kt.nextInt();
			System.out.println("Enter salary:");
			Long dt=kt.nextLong();
			System.out.println("Enter designation");
			String et=kt.next();
			Empdet gt=new Empdet(bt,ct,dt,et);
			gt.display();
		break;
		default: System.out.println("total no of employees:"+n);
		}
		
      ee.exit();
	}

}
