package employee;

public class Empdet {
	int rno;
	String name;
	int age;
	long salary;
	String designation;
	Empdet(int rno,String name,int age,long salary,String designation)
	{
		this.rno=rno;
		this.name=name;
		this.age=age;
		this.salary=salary;
		this.designation=designation;
	}
	void createemp()
	{
		System.out.println(rno+":{'name':"+"'"+name+"', 'age':"+age+", 'Salary':"+salary+", 'designation':"+designation);
	}
	String k="clerk";
    String l="Programmer";
    String m="manager";
    void fixsalary()
    {
   	 if(designation==k)
   		 salary=8000;
   	 else
   		 if(designation==l)
   			 salary=25000;
   	else if(designation==m)
   		   salary=80000;
   			 
    }
    void raisesalary()
    {
   	 if(designation==k)
   		 salary=salary+2000;
   	 else
   		 if(designation==l)
   			 salary=salary+5000;
   	else if(designation==m)
   		   salary=salary+10000;
   			 
    }
    void displaysal()
    {
    	System.out.println("Salary raise:"+ salary);
    }
    Empdet(String name,int age,long salary,String designation)
    {
	  this.name=name;
	  this.age=age;
	  this.salary=salary;
	  this.designation=designation;
	}
    void display()
    {
    	System.out.println(name+" "+age+" "+salary+" "+designation);
    }
    void exit()
    {
    	System.out.println("----details gathered---");
    }
     
     
}
