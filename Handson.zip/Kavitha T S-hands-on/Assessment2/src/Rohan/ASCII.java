package Rohan;

import java.util.Scanner;

public class ASCII {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		char c1,c2,c3,c4;
		
		System.out.println("Enter the input1--");
		int input1=sc.nextInt();
		
		System.out.println("Enter the input2--");
		int input2=sc.nextInt();
		
		System.out.println("Enter the input3--");
		int input3=sc.nextInt();
		
		System.out.println("Enter the input4--");
		int input4=sc.nextInt();
		
		c1=(char)input1;
		c2=(char)input2;
		c3=(char)input3;
		c4=(char)input4;
		System.out.println(input1+"-"+c1);
		System.out.println(input2+"-"+c2);
		System.out.println(input3+"-"+c3);
		System.out.println(input4+"-"+c4);
		
		
		

	}

}
