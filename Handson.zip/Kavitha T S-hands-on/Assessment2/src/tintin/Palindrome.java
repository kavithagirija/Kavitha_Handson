package tintin;

import java.util.Scanner;

public class Palindrome
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input--");
		long input=sc.nextInt();
		
		long store=input;
		long rem,input1=0;
		
		if(input<0)
		{
			System.out.println("Invalid input");
		}
		
		while(input!=0)
		{
			rem=input%10;
			input1=(input1*10)+rem;
			input/=10;
		}
		
		input=store;
		
		if(input==input1)
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}
		
		
	}

}
