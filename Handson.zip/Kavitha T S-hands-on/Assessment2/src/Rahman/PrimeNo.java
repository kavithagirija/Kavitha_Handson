package Rahman;

import java.util.Scanner;

public class PrimeNo {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the input1--");
		long input1=sc.nextInt();
		System.out.println("Enter the input2--");
		long input2=sc.nextInt();
        
		int f;
        
        if(input1>input2 || input1<0 || input2<0)
        {
        	System.out.println("Provide valid input");
        }
        
		while(input1<input2)
		{
			f=0;
		  for(long j=2;j<=input1/2;j++)
		  {
			  if(input1%j==0)
			  {
				  f=1;
				  break;
			  }
		  }
		  if(f==0)
		  {
			  System.out.print(input1+" ");
		  }
		  input1++;
		}
	}

}
