package calculator.com;

import java.util.Scanner;

public class Module {
	
	Scanner in=new Scanner(System.in);
	System.out.println("Enter the value..");
	int n=in.newInt();
	    switch(n)
	   {
	    case 1: public void add()
		    {
		    	Scanner ad=new Scanner(System.in);
		    	System.out.println("Enter the value");
		    	int a1=ad.newInt();
		    	int a2=ad.newInt();
		    	System.out.println("Addition--"+(a1+a2));
		    }
	     break;
	   case 2: public void sub(int a,int b)
            {
		        int x=a;
		        int y=b;
    	       System.out.println("subraction--"+(x-y));
            }
	   break;
	   case 3: public void mul()
              {
		Scanner mul1=new Scanner(System.in);
    	int m1=mul1.newInt();
    	int m2=mul2.newInt();
    	System.out.println("multiplication--"+(m1*m2));
    	        }
       break;
	   case 4: public void div()
           {
		Scanner di1=new Scanner(System.in);
    	int d1=di1.newInt();
    	int d2=di2.newInt();
    	System.out.println("division--"+(d1/d2));
    	    }
	    break;
   
	}


}
