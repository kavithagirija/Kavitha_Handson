package calculator.com;

public class Oper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Module m=new Module();
		m.sub(10, 5);

	}

}
