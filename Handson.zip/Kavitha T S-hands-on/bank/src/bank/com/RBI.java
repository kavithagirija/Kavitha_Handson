package bank.com;

public class RBI 
{
	double initamount,addamount,wdamount;
	 customer det;
	
	
   public RBI(double initamount, double addamount, double wdamount,customer det) 
   {
		super();
		this.initamount = initamount;
		this.addamount = addamount;
		this.wdamount = wdamount;
		this.det=det;
   }
   void credit()
   {
	   initamount=initamount+addamount;
   }
   void withdraw() throws Throw
   {
		if(initamount<wdamount)
		{
			throw new Throw("***Withdrawal is failed***");
		}
		else
		{
			initamount=initamount-wdamount;
		}
   }
   void balance()
   {
	   System.out.println("Enter the balance amount:"+initamount);  
   }
   void homeLoan(double amountH,double interest)
   {
	 System.out.println("Loan amount for home");  
   }
   void carLoan(double amountH,double interest)
   {
	 System.out.println("Loan amount for car");
   }
}
class SBI extends RBI
{
	public SBI(double initamount, double addamount, double wdamount,customer det) 
	{
		super(initamount, addamount, wdamount, det);
	}
	@Override
	   void credit()
	   {
		   initamount=initamount+addamount;
	   }
	   void withdraw() throws Throw
	   {
			if(initamount<wdamount)
			{
				throw new Throw("***Withdrawal is failed***");
			}
			else
			{
				initamount=initamount-wdamount;
			}
	   }
	   void balance()
	   {
		   System.out.println("Enter the balance amount:"+initamount);  
	   }
	   void homeLoan(double amountH,double interest)
	   {
		   System.out.println("****SBI*******"+"\n"+"customer name:"+det.name+"\n"+"IFSC:"+det.IFSC+"\n"+" branch:"+det.branch+"\n"+" Loan amount for home:"+amountH+"\n"+" Interest amount:"+(amountH+interest)/100);
	   }
	   void carLoan(double amountC,double interestt)
	   {
		   System.out.println("\n"+"Loan amount for car:"+amountC+"\n"+"Interest"+(amountC+interestt)/100);
		   System.out.println("\n");
	   }
	
}
class HDFC extends RBI
{
	public HDFC(double initamount, double addamount, double wdamount,customer det)
	{
		super(initamount, addamount, wdamount,det);
		
	}
	@Override
	   void credit()
	   {
		   initamount=initamount+addamount;
	   }
	   void withdraw() throws Throw
	   {
			if(initamount<wdamount)
			{
				throw new Throw("***Withdrawal is failed***");
			}
			else
			{
				initamount=initamount-wdamount;
			}
	   }
	   void balance()
	   {
		   System.out.println("Enter the balance amount:"+initamount);  
	   }
	   void homeLoan(double amountH,double interest)
	   {
		   System.out.println("****SBI*******"+"\n"+"customer name:"+det.name+"\n"+"IFSC:"+det.IFSC+"\n"+" branch:"+det.branch+"\n"+" Loan amount for home:"+amountH+"\n"+" Interest amount:"+(amountH+interest)/100);
	   }
	   void carLoan(double amountC,double interestt)
	   {
		   System.out.println("\n"+"Loan amount for car:"+amountC+"\n"+"Interest"+(amountC+interestt)/100);
		   System.out.println("\n");
	   }
	   
	
}
class AXIS extends RBI
{
	public AXIS(double initamount, double addamount, double wdamount,customer det) 
	{
		super(initamount, addamount, wdamount,det);
		
	}
	@Override
	   void credit()
	   {
		   initamount=initamount+addamount;
	   }
	   void withdraw() throws Throw
	   {
			if(initamount<wdamount)
			{
				throw new Throw("***Withdrawal is failed***");
			}
			else
			{
				initamount=initamount-wdamount;
			}
	   }
	   void balance()
	   {
		   System.out.println("Enter the balance amount:"+initamount);  
	   }
	   void homeLoan(double amountH,double interest)
	   {
		   System.out.println("****SBI*******"+"\n"+"customer name:"+det.name+"\n"+"IFSC:"+det.IFSC+"\n"+" branch:"+det.branch+"\n"+" Loan amount for home:"+amountH+"\n"+" Interest amount:"+(amountH+interest)/100);   }
	   void carLoan(double amountC,double interestt)
	   {
		   System.out.println("\n"+"Loan amount for car:"+amountC+"\n"+"Interest"+(amountC+interestt)/100);
		   System.out.println("\n");
	   }
	
}
