package bank.com;

public class Throw extends Exception
{
    Throw(String MSG)
    {
    	super(MSG);
    }
}
