package bank.com;

import java.util.Scanner;

public class Manage 
{

	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the initial amount");
		double inamt=in.nextDouble();
		System.out.println("Enter the withdrawal amount");
		double wdamt=in.nextDouble();
		System.out.println("Enter the credited amount");
		double adamt=in.nextDouble();
		System.out.println("Enter the name of the customer");
		String nam=in.next();
		System.out.println("Enter the Loan amount for home");
		double loanh=in.nextDouble();
		System.out.println("Enter the Loan amount for car");
		double loanc=in.nextDouble();
		System.out.println("Enter the ifsc code");
		String ifsc=in.next();
		System.out.println("Enter the branch");
		String brAnch=in.next();
		customer C=new customer(nam,ifsc,brAnch);
		
		RBI S=new SBI(inamt,adamt,wdamt,C);
		S.credit();
		try 
		{
			S.withdraw();
		} 
		catch (Throw e) 
		{
	
			e.printStackTrace();
		}
		S.balance();
		S.homeLoan(loanh,3);
		S.carLoan(loanc, 2);
		
		
		
		System.out.println("Enter the initial amount");
		double inamt1=in.nextDouble();
		System.out.println("Enter the withdrawal amount");
		double wdamt1=in.nextDouble();
		System.out.println("Enter the credited amount");
		double adamt1=in.nextDouble();
		System.out.println("Enter the ifsc code");
		String ifsc1=in.next();
		System.out.println("Enter the branch");
		String brAnch1=in.next();
		customer C2=new customer(nam,ifsc1,brAnch1);
		RBI H=new HDFC(inamt1,adamt1,wdamt1,C2);
		H.credit();
		try 
		{
			H.withdraw();
		} 
		catch (Throw e) 
		{
	        e.printStackTrace();
		}
		H.balance();
		H.homeLoan(loanh,3);
		H.carLoan(loanc, 2);
		
		
		System.out.println("Enter the initial amount");
		double inamt2=in.nextDouble();
		System.out.println("Enter the withdrawal amount");
		double wdamt2=in.nextDouble();
		System.out.println("Enter the credited amount");
		double adamt2=in.nextDouble();
		System.out.println("Enter the ifsc code");
		String ifsc2=in.next();
		System.out.println("Enter the branch");
		String brAnch2=in.next();
		customer C1=new customer(nam,ifsc2,brAnch2);
		
        RBI A=new AXIS(inamt2,adamt2,wdamt2,C1);
		A.credit();
		try 
		{
			A.withdraw();
		} 
		catch (Throw e) 
		{
	
			e.printStackTrace();
		}
		A.balance();
		A.homeLoan(loanh,3);
		A.carLoan(loanc, 2);

	}

}
