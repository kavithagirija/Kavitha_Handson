package bank.com;

public class customer 
{
  String name;
  String IFSC;
  String branch;
public customer(String name, String iFSC, String branch) 
{
	super();
	this.name = name;
	IFSC = iFSC;
	this.branch = branch;
}
}
